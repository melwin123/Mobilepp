class BannerImage {
  String imageUrl;
  String imageSlug;

  BannerImage({this.imageSlug, this.imageUrl});
}
